/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jd522sa;

import java.util.Date;


/**
 *
 * @author ELIPHAS
 */
public class Account {
    
    int id;
    double balance;
    Date dateCreated = new Date();
    
     Account(int ID,Date date){
     
          id=ID;
        dateCreated=date;
    
    }
     
     //set method
      void setID(int ID) {
        id=ID;
    }
      
      //get method
       int getID() {
       return id;
    }
      
       //set method
       void setbalance(double Balance) {
        balance=Balance;
    }
       
       //get method
        double getbalance() {
       return balance;
    }
       
       //set method
        void setDate(Date date) {
       dateCreated=date;
    }
        
        //get Method
         Date getcredit_hours() {
       return dateCreated;
    }
          double Withdraw(int WithAmount){
    return  balance=balance-WithAmount;
    }
       
          double deposit(int DepAmount){
              return balance=balance+DepAmount;
          }
          
       double printStatement(String statement){
           
              return balance;
          }    
}

   