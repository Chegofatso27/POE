USE [BALANCE]
GO

UPDATE [dbo].[balance database]
   SET [ID] = <ID, numeric(18,0),>
      ,[USERNAME] = <USERNAME, text,>
      ,[INITIAL BALANCE] = <INITIAL BALANCE, money,>
      ,[CURRENT BALANCE] = <CURRENT BALANCE, money,>
 WHERE <Search Conditions,,>
GO

