# JavaBankApp
This project started off as a simple console based bank application. It has evolved into a Swing based application with database to demonstrate the process. Videos of the process are on youtube at http://goo.gl/evqvrh

To download the code before the database was added check out the branch https://github.com/introtocomputerscience/JavaBankApp/tree/bankapp-without-database
