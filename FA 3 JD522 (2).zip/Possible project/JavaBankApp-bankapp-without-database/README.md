# JavaBankApp
This project started off as a simple console based bank application. It is evolving into a Swing based application to demonstrate the process. Videos of the process are on youtube at http://goo.gl/evqvrh
